<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/index_css.php">
    <?php include("entete.php"); ?>
</head>

<body>
    <div id="cb">
        <?php include("menul.php"); ?>
        <div id="cbc">
            <div id="ucbc1">
                <h1><u>Découvrez notre nouveau Menu</u></h1>
                <hr>
            </div>
            <div id="ucbc2">
                <img class="promo" src="img/double_steakhouse.jpeg" width="400px" height="300px">
            </div>
        </div>
        <?php include("menur.php"); ?>
    </div>
</body>
<footer>
    <?php include("footer.php"); ?>
</footer>

</html>
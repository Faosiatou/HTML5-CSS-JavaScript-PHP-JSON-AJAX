        <div id="cbl">
                <!--<input type="checkbox" id="chec">
                <!--<label for="chec">
                    <img src="img/loupe.png" width="25px" height="25px">
                </label>-->
                <nav id="nav-left">
                    <ul>
                        <li><a href="index.php">Accueil</a></li>
                        <li><a href="page1.php">Menus</a></li>
                        <li><a href="page2.php">Burgers</a></li>
                        <li><a href="page3.php">Pizzas</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="connexion.php">Connexion</a></li>
                    </ul>
                </nav>
        </div>

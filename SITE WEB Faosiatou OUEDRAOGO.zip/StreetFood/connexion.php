<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<?php

?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/connexion_css.php">
    <?php include("entete.php"); ?>
</head>

<body>
    <div id="cb">
        <?php include("menul.php"); ?>
        <div id="cbc">
        <div id="connexion">
            <h2><u>Connexion</u></h2>
        <form>
            <label for="id">Nom Utilisateur:</label>
            <input type="text" name="name" id="nom" minlength="2" maxlength="20">
            <br><br>
            <label for="site">mot de passe:</label>
            <input type="password" id="site" name="q" minlength="2" maxlength="30">
            <br><br>
            <input type="submit" value="Se connecter">
        </form>
        </div>
        <br><br>
        <div id="inscription">
            <h2><u>Inscription</u></h2>
            <form>
            <label for="id">Nom Utilisateur:</label>
            <input type="text" name="name" id="nom" minlength="2" maxlength="20">
            <br><br>
            <label for="site">mot de passe:</label>
            <input type="password" id="site" name="q" minlength="2" maxlength="30">
            <br><br>
            <input type="submit" value="S'inscrire">
            </form>
        </div>
        <?php include("menur.php"); ?>
    </div>
</body>
<footer>
    <?php include("footer.php"); ?>
</footer>

</html>

<?php
    header('Content-type: text/css; charset:UTF-8');
?>

/*all block*/
html{background-color: whitesmoke; font-family: arial, sans-serif, Verdana, sans-serif;}
/*head*/

#tb {
	display: flex;
	position: absolute;
	flex-direction: row;
    top: 0%;
	width: 100%;
	height: 10%;
}
#logo {
    margin-left: 5%;
}
#utb {
    margin-left: 2%;
}
nav.menuh {
	background-color: gainsboro;
	border: 2px solid black;
	padding: 5px;
	
}

nav.menuh ul {
	list-style-type: none;
	display: inline-flex;
}

nav.menuh>ul>li{text-align: center;display: inline-flex; width:100px; margin-left: 10px; border-radius: 10px 10px 10px 10px;}
nav.menuh li{width:100px;position:relative;}
nav.menuh>ul>li>ul{position:absolute;left: -100000%;background: gainsboro;border:2px solid black; border-radius: 10px 10px 10px 10px; text-align: center;}
nav.menuh>ul>li:hover>ul{top:100%;left:0%;}
nav.menuh li:hover{background-image: linear-gradient(gainsboro,white);}
nav.menuh a{display: block;text-decoration: none;padding:10px;color: black;}
nav.menuh a:hover{text-decoration: underline;color: black;}
nav.menuh li.logor:hover{background-image: none;}
nav.menuh li.logor{margin-left: 105px; margin-right: -20px;}

#panier {
    margin-left: 5%;
}

nav.panier {
	background-color: gainsboro;
	border: 2px solid black;
	padding: 5px;
	
}

nav.panier ul {
	list-style-type: none;
	display: inline-flex;
}

nav.panier>ul>li{text-align: center;display: inline-flex; width:100px; margin-left: 10px; border-radius: 10px 10px 10px 10px;}
nav.panier li{width:100px;position:relative;}
nav.panier li:hover{background-image: linear-gradient(gainsboro,white);}
nav.panier a{display: block;text-decoration: none;padding:10px;color: black;}
nav.panier a:hover{text-decoration: underline;color: black;}


/*body*/
#cb {
    display: flex;
    flex-direction: row;
    position: absolute;
    left: 0%;
    top: 15%;
    width: 100%;
    height: 70%;
}
#cbl {
    width: 15%;
    height: 70%;
}
input[type="checkbox"] {
    padding: 50px;
}

input[type="checkbox"]:checked ~ #nav-left {
    transform: translateX(0%);
}

#nav-left {
    background: gainsboro;
    position: absolute;
    left: 0%;
    top: 15%;
    border: solid black 2px;
    transition: left 0.75s;
}

#nav-left ul {
    list-style-type: none;
    padding: 0;
}

#nav-left>ul>li{text-align: center;display:flex; width:100px; margin-left: 10px; border-radius: 10px 10px 10px 10px;}
#nav-left li{width:100px;position:relative;}
#nav-left>ul>li:hover>ul{top:100%;left:0%;}
#nav-left li:hover{background-image: linear-gradient(gainsboro,white);}
#nav-left a{display: block;text-decoration: none;padding:10px;color: black;}
#nav-left a:hover{text-decoration: underline;color: black;}

#cbc{
    display: flex;
    flex-direction: column;
    text-align: center;
    width: 70%;
    height: 70%;
    
}

div#fmenu {
    display: flex;
    flex-direction: row;
}

div#smenu {
    display: flex;
    flex-direction: row;
}

/*pizzas*/
.img_menu{
    display: block;
    width: 160px;
    margin-left: auto;
    margin-right: auto;
}

.menu1{
    display: inline-flex;
    
}

.menu2{
    display: inline-flex;
    margin-right:auto;
}

.menu3{
    display: inline-flex;
    margin-right:auto;
}

.menu4{
    display: inline-flex;
    margin-right:auto;
    width: 325px;
    margin-left:20%; 
    margin-right:auto;
    height: 270px ;
}

.menu5{
    display: inline-flex;
    margin-right:auto;
    width: 325px;
    margin-right:auto;
    height: 270px ;
}

.prix{
    text-align: right;
    font-weight: bold;
    color: red;
}


label[for = ingredient]
{
    /*font-size:  10px ;*/
}

legend{
    font-weight: bold;
}

fieldset{
    background-color: gainsboro;
    border: solid black 2px;
}

div#stock1,div#stock2,div#stock3,div#stock4,div#stock5{
    color: red;
}

/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
-webkit-appearance: none;
margin: 0;
}

/* Firefox */
input[type=number] {
-moz-appearance: textfield;
}
/*pizzas*/
.img_menu{
    display: block;
    width: 160px;
    margin-left: auto;
    margin-right: auto;
}

.menu1{
    display: inline-flex;
    margin-left:20%; 
    margin-right:auto;
    width: 325px;
    height: 270px ;
}

.menu2{
    display: inline-flex;
    margin-right:auto;
    width: 325px;
    height: 270px ;
}

.menu3{
    display: inline-flex;
    margin-right:auto;
    width: 325px;
    height: 270px ;
}

.menu4{
    display: inline-flex;
    margin-right:auto;
    width: 325px;
    margin-left:20%; 
    margin-right:auto;
    height: 270px ;
}

.menu5{
    display: inline-flex;
    margin-right:auto;
    width: 325px;
    margin-right:auto;
    height: 270px ;
}

.prix{
    text-align: right;
    font-weight: bold;
    color: red;
}


label[for = ingredient]
{
    /*font-size:  10px ;*/
}

legend{
    font-weight: bold;
}

fieldset{
    background-color: gainsboro;
    border: solid black 2px;
}

div#stock1,div#stock2,div#stock3,div#stock4,div#stock5{
    color: red;
}

/* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
-webkit-appearance: none;
margin: 0;
}

/* Firefox */
input[type=number] {
-moz-appearance: textfield;
}


#cbr {
    width: 15%;
    height: 70%;
}




/*footer*/
footer  {
    display: inline-flex;
    flex-direction: row;
    list-style-type: none;
    position: absolute;
    left: 0%;
    width: 100%;
    height: 10%;
    top:110%;
    text-align: center;
}

div#fb {
    margin-left: 15%;
    width: 23.33%;
}

div#info1 {
    list-style-type: none;
    width: 23.33%;
}
#info1 ul {
    list-style-type: none;
}
#info1 > ul > li > ul {
    list-style-type: none;
}  

div#info2 {
    width: 23.33%;
}

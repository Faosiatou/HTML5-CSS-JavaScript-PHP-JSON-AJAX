<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/panier_css.php">
    <?php include("entete.php"); ?>
</head>

<body>
    <div id="cb">
        <?php include("menul.php"); ?>
        <div id="cbc">
        
        </div>
        <?php include("menur.php"); ?>
    </div>
</body>
<footer>
    <?php include("footer.php"); ?>
</footer>

</html>

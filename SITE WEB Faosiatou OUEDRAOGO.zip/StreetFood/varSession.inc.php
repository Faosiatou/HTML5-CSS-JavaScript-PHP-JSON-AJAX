<?php
session_start();
$Session_ID = session_id();



$_SESSION = array(

    array("menu1", "MENU STEAKHOUSE", "img/menu_steakhouse.jpeg", "1 burger steakhouse", "+ frittes + 1 boisson &emsp; &emsp;&emsp;&emsp;", "9,95€", "stock1", "quantiteMenu1"),
    array("menu2", "MENU DOUBLE CHEESE BACON", "img/menu_double_cheese_bacon.jpeg", "1 burger double cheese bacon", "+ frittes + 1 boisson &emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;", "10,95€", "stock2", "quantiteMenu2"),
    array("menu3", "MENU DOUBLE STEAKHOUSE", "img/menu_double_steakhouse.jpeg", "1 burger double steakhouse", "+ frittes + 1 boisson&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;", "11,50€", "stock3", "quantiteMenu3"),
    array("menu4", "MENU SOLO", "img/menu_solo.png", "1 pizza au choix", "+ 1 dessert +1 boisson &emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;", "20,90€", "stock4", "quantiteMenu4"),
    array("menu5", "MENU 2 PERSONNES", "img/menu_2_personnes.png", "2 pizzas au choix", "+ 2 boissons + 2 desserts &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;", "32,50€", "stock5", "quantiteMenu5")
);



?>
<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/page3_css.php">
    <script type="text/javascript" src="js/page_js.php"></script>
    <?php include("entete.php"); ?>
</head>

<body>
    <div id="cb">
        <?php include("menul.php"); ?>
        <div id="cbc">
        <div id="align">
        <h4><u>Nos Pizzas</u></h4>
        <hr>
        </div>
        <div id="fmenu">
        <fieldset class="pizza1">
            <legend>REINE</legend>
            <ul>
              <li>
                <a href="#"><img class="img_pizza" src="img/reine.png" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>Sauce tomate, fromage, jambon, champignons, origanl</label>
              </li>
              <li class="prix">
                <label>15,50€</label>
              </li>
              <div id = "stock1">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins1()">-</button>
                <input type="number" name="quantite" id="quantiteMenu1" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus1()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="pizza2">
            <legend>VEGETARIENNE</legend>
            <ul>
              <li>
                <a href="#"><img class="img_pizza" src="img/vegetarienne.png" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>tomate, fromage, champignons, poivrons, olives, origan</label>
              </li>
              <li class="prix">
                <label>15,50€</label>
              </li>
              <div id = "stock2">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins2()">-</button>
                <input type="number" name="quantite" id="quantiteMenu2" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus2()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="pizza3">
            <legend>MEXICAINE</legend>
            <ul>
              <li>
                <a href="#"><img class="img_pizza" src="img/mexicaine.png" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>Sauce tomate, fromage, pepperoni, merguez, poivrons, olives, origan</label>
              </li>
              <li class="prix">
                <label>16€</label>
              </li>
              <div id = "stock3">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins3()">-</button>
                <input type="number" name="quantite" id="quantiteMenu3" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus3()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        </div>
        <div id="smenu">
        <fieldset class="pizza4">
            <legend>5 FROMAGES</legend>
            <ul>
              <li>
                <a href="#"><img class="img_pizza" src="img/4-fromages.png" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>sauce tomate, mozzarella, provolone, gorgonzola, chèvre, parmesan, formage à raclette</label>
              </li>
              <li class="prix">
                <label>16,50€</label>
              </li>
              <div id = "stock4">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins4()">-</button>
                <input type="number" name="quantite" id="quantiteMenu4" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus4()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="pizza5">
            <legend>4 SAISONS</legend>
            <ul>
              <li>
                <a href="#"><img class="img_pizza" src="img/4-saisons.png" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>sauce tomate, fromage, jambon, artichauts, champignons, olives, origan</label>
              </li>
              <li class="prix">
                <label>15,50€</label>
              </li>
              <div id = "stock5">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins5()">-</button>
                <input type="number" name="quantite" id="quantiteMenu5" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus5()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <button id = "bouton_stock" onclick="afficheStock()">stock</button>
        </div>
        </div>
        <?php include("menur.php"); ?>
    </div>
</body>
<footer>
    <?php include("footer.php"); ?>
</footer>

</html>

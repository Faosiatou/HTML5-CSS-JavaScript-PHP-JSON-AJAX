<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/page2_css.php">
    <script type="text/javascript" src="js/page_js.php"></script>
    <?php include("entete.php"); ?>
</head>

<body>
    <div id="cb">
        <?php include("menul.php"); ?>
        <div id="cbc">
        <div id="align">
        <h4><u>Nos Burgers</u></h4>
        <hr>
        </div>
        <div id="fmenu">
<fieldset class="burger1">
            <legend>STEAKHOUSE</legend>
            <ul>
              <li>
                <a href="#"><img class="img_burger" src="img/steakhouse.jpeg" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>Oignons croustillons, Bacon, Sauce barbecue, Viande de bœuf, grillée Fromage fondu</label>
              </li>
              <li class="prix">
                <label>6,50€</label>
              </li>
              <div id = "stock1">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins1()">-</button>
                <input type="number" name="quantite" id="quantiteMenu1" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus1()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="burger2">
            <legend>DOUBLE STEAKHOUSE</legend>
            <ul>
              <li>
                <a href="#"><img class="img_burger" src="img/double_steakhouse.jpeg" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient><br>2 Viande de bœuf grillée, Oignons croustillons, Bacon, Sauce barbecue</label>
              </li>
              <li class="prix">
                <label>8,50€</label>
              </li>
            </li>
            <div id = "stock2">
              <output name="calcul_stock">Stock = 10</output>
            </div>
            <div id = panier_a>
              <button id = "bouton_moins" onclick="moins2()">-</button>
              <input type="number" name="quantite" id="quantiteMenu2" min="0" max="10" style="width: 2em;" >
              <button id = "bouton_plus" onclick="plus2()">+</button>
              <button id = "bouton_Panier">Ajouter au panier</button>
            </div>
            </ul>
        </fieldset>
        <fieldset class="burger3">
            <legend>TRIPLE CHEESE</legend>
            <ul>
              <li>
                <a href="#"><img class="img_burger" src="img/triple_cheese.jpeg" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient><br>3 Viande de bœuf grillée, 3 Tranches de fromage fondu, Ketchup & Moutarde, 2 Rondelles de cornichons</label>
              </li>
              <li class="prix">
                <label>5,30€</label>
              </li>
              <div id = "stock3">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins3()">-</button>
                <input type="number" name="quantite" id="quantiteMenu3" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus3()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        </div>
        <div id="smenu">
        <fieldset class="burger4">
            <legend>DOUBLE CHEESE BACON</legend>
            <ul>
              <li>
                <a href="#"><img class="img_burger" src="img/double_cheese_Bacon.jpeg" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient><br>2 Viande de bœuf grillée, Bacon, Sauce barbecue, Fromage fondu</label>
              </li>
              <li class="prix">
                <label>7,50€</label>
              </li>
              <div id = "stock4">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins4()">-</button>
                <input type="number" name="quantite" id="quantiteMenu4" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus4()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="burger5">
            <legend>CRISPY CHICKEN</legend>
            <ul>
              <li>
                <a href="#"><img class="img_burger" src="img/crispy_chicken.jpeg" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient><br>Poulet croustillant, Salade, Tomates, Mayonnaise</label>
              </li>
              <li class="prix">
                <label>4,50€</label>
              </li>
              <div id = "stock5">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = panier_a>
                <button id = "bouton_moins" onclick="moins5()">-</button>
                <input type="number" name="quantite" id="quantiteMenu5" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus5()">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <button id = "bouton_stock" onclick="afficheStock()">stock</button>
        </div>
        </div>
        <?php include("menur.php"); ?>
    </div>
</body>
<footer>
    <?php include("footer.php"); ?>
</footer>

</html>

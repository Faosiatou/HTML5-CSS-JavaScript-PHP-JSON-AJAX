<?php
    session_start();
    include("varSession.inc.php");
?>

<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta author="Teggar Farès">
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" type="text/css" href="css/page1_css.php">
        <script type="text/javascript" src="js/page_js.php"></script> 
        <?php include("entete.php"); ?>
    </head>
    <body>
        <div class="alignCenter">
            <h1>Nos Menus  </h1>
        </div>
        <hr style="width:60%;margin-left:20%">      

        <?php include("liste_menus.php"); ?>

        <?php
            for($i = 0; $i < 5; $i++) {
        ?>

            <fieldset class=<?php echo $_SESSION[$i][0]; ?> >
                <legend><?php echo $_SESSION[$i][1]; ?></legend>
                <ul>
                <li>
                    <a href="#"><img class="img_menu" src= <?php echo $_SESSION[$i][2] ; ?> onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
                </li>                
                <li>
                    <label for=ingredient><?php echo $_SESSION[$i][3]; ?> </label>
                </li>
                <li>
                    <label for=ingredient><?php echo $_SESSION[$i][4]; ?></label>
                </li>
                
                <li class="prix">
                    <label><?php echo $_SESSION[$i][5]; ?></label>
                </li>
                <div id =<?php echo $_SESSION[$i][6]; ?>>
                    <output name="calcul_stock">Stock = 10</output>
                </div>
                <div id = "panier">
                    <button id = "bouton_moins" onclick="moins(<?php echo $i+1 ; ?>)">-</button>
                    <input type="number" name="quantite" id=<?php echo $_SESSION[$i][6]; ?> min="0" max="10" style="width: 2em;" >
                    <button id = "bouton_plus" onclick="plus(<?php echo $i+1 ; ?>)">+</button>
                    <button id = "bouton_Panier">Ajouter au panier</button>
                </div>
                </ul> 
            </fieldset>

        <?php
            }
        ?>
<!--
        <fieldset class="menu1">
            <legend>MENU STEAKHOUSE</legend>
            <ul>
              <li>
                <a href="#"><img class="img_menu" src="img/menu_steakhouse.jpeg" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>1 burger steakhouse </label>
              </li>
              <li>
                <label for=ingredient>+ frittes + 1 boisson &emsp; &emsp;&emsp;&emsp;</label>
              </li>
              
              <li class="prix">
                <label>9,95€</label>
              </li>
              <div id = "stock1">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = "panier">
                <button id = "bouton_moins" onclick="moins(1)">-</button>
                <input type="number" name="quantite" id="quantiteMenu1" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus(1)">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="menu2">
            <legend>MENU DOUBLE CHEESE BACON</legend>
            <ul>
              <li>
                <a href="#"><img class="img_menu" src="img/menu_double_cheese_bacon.jpeg" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>1 burger double cheese bacon </label>
              </li>
              <li>
                <label for=ingredient>+ frittes + 1 boisson &emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp; </label>
              </li>
              
              <li class="prix">
                <label>10,95€</label>
              </li>
              <div id = "stock2">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = "panier">
                <button id = "bouton_moins" onclick="moins(2)">-</button>
                <input type="number" name="quantite" id="quantiteMenu2" min="0" max="10" style="width: 2em">
                <button id = "bouton_plus" onclick="plus(2)">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="menu3">
            <legend>MENU DOUBLE STEAKHOUSE</legend>
            <ul>
              <li>
                <a href="#"><img class="img_menu" src="img/menu_double_steakhouse.jpeg" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                               
              <li>
                <label for=ingredient>1 burger double steakhouse </label>
              </li>
              <li>
                <label for=ingredient>+ frittes + 1 boisson&emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</label>
              </li>
              
              <li class="prix">
                <label>11,50€</label>
              </li>
              <div id = "stock3">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = "panier">
                <button id = "bouton_moins" onclick="moins(3)">-</button>
                <input type="number" name="quantite" id="quantiteMenu3" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus(3)">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="menu4">
            <legend>MENU SOLO</legend>
            <ul>
              <li>
                <a href="#"><img class="img_menu" src="img/menu_solo.png" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>1 pizza au choix </label>
              </li>
              <li>
                <label for=ingredient>+ 1 dessert +1 boisson &emsp; &emsp;&emsp;&emsp;&emsp;&emsp;&emsp; </label>
              </li>
              
              <li class="prix">
                <label>20,90€</label>
              </li>
              <div id = "stock4">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = "panier">
                <button id = "bouton_moins" onclick="moins(4)">-</button>
                <input type="number" name="quantite" id="quantiteMenu4" min="0" max="10" style="width: 2em;" >
                <button id = "bouton_plus" onclick="plus(4)">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
        <fieldset class="menu5">
            <legend>MENU 2 PERSONNES</legend>
            <ul>
              <li>
                <a href="#"><img class="img_menu" src="img/menu_2_personnes.png" onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
              </li>                
              <li>
                <label for=ingredient>2 pizzas au choix </label>
              </li>
              <li>
                <label for=ingredient>+ 2 salades mixtes </label>
              </li>
              <li>
                <label for=ingredient>+ 2 boissons + 2 desserts &emsp;&emsp;&emsp;&emsp;&emsp;&emsp;</label>
              </li>
              
              <li class="prix">
                <label>32,50€</label>
              </li>
              <div id = "stock5">
                <output name="calcul_stock">Stock = 10</output>
              </div>
              <div id = "panier">
                <button id = "bouton_moins" onclick="moins(5)">-</button>
                <input type="number" name="quantite" id="quantiteMenu5" min="0" max="10" style="width: 2em">
                <button id = "bouton_plus" onclick="plus(5)">+</button>
                <button id = "bouton_Panier">Ajouter au panier</button>
              </div>
            </ul>
        </fieldset>
-->
        <button id = "bouton_stock" onclick="afficheStock()">stock</button>

        <div id="cblhistory">
            <h4>Notre Histoire</h4>
            <p>A compléter</p>
        </div>
    </body>
    <footer>
    <?php include("footer.php"); ?>
    </footer>
</html>
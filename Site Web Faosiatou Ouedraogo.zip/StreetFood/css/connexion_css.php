<?php
    header('Content-type: text/css; charset:UTF-8');
?>

/*all block*/
html{font-family: arial, sans-serif, Verdana, sans-serif;}
/*head*/

/*head*/
#topblock {
  display: flex;
  justify-content: center;
  position: absolute;
  left: 0%;
  top: 0%;
  width: 100%;
  height: 15%;
  background-color: blanchedalmond;
  padding: 0;
  margin: 0;
}

img.imagelogo {
  margin-right: 0px;
}

nav.menuhead {
  font-size: large;
  margin-left: 25px;
}

nav.menuhead ul {
  display: flex;
  list-style-type: none;
  padding: 10px;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 15.3);
  background-color: #FFF;
  max-width: auto;
  min-width: 500px;
}

nav.menuhead>ul>li {display: inline-flex; text-align: center; width: auto;padding: 20px;}
nav.menuhead ul li:hover {box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);}
nav.menuhead>ul>li>ul {position: absolute; left: -1000px; flex-direction: column; padding: 20px;}
nav.menuhead ul a{color: black; text-decoration: none;}

#idblock {
  display: flex;
  flex-flow: row wrap;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 15.3);
  background-color: #FFF;
  margin-top: 18px;
  width: 145px;
  height: 81px;
  margin-left: 25px;
  justify-content: center;
}
#idblock a:hover {box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);}

#idblock a {
  color: black;
  text-decoration: none;
}

/*body*/
#lateral-panel {
  z-index: 9999;                  /* pour être au dessus des autres éléments */
  display: inline-flex;
  flex-direction: column;
  position: fixed;                /* ne suit pas le scroll de la page et sert de réfèrent */
  top: 15%;                         /* position en haut */
  left: 0%;                        /* à gauche */
  width: 15%;                    /* valeur de largeur pour tout le contenu */
  height: 75%;              /* occupe toute la hauteur du viewport */
  transform: translateX(-100%);   /* on déplace à gauche pour ne pas interférer avec le document */
}

#lateral-panel-input {
  position: absolute;           /* pour sortir l'élément du flux */
  left: -999em;                 /* position hors de la fenêtre */
}

#lateral-panel-label {
  z-index: 1;                   /* on le met au dessus */
  position: absolute;           /* pour sortir l'élément du flux, il va bouger */
  top: 0;                       /* position en haut */
  left: 100%;                   /* alignement sur le bord droit du parent */
  width: 3em;                   /* dimensions respectables */
  height: 3em;
  cursor: pointer;
}

#lateral-panel-bloc {
  z-index: 0;                   /* mise au niveau zéro */
  position: absolute;           /* pour sortir l'élément du flux, il va bouger */
  top: 0;                       /* position en haut */  
  left: 0;                      /* alignement sur bord gauche du parent */
  box-sizing: border-box;       /* modèle de boîte, plus simple à gérer */
  width: 100%;                  /* largeur 100% de son parent */
  height: 100%;                 /* hauteur 100% de son parent */
  padding: 0em;                 /* on décolle le contenu du bord */
  overflow: auto;               /* rien ne doit déborder */
}

#lateral-panel-bloc nav {
  font-size: larger;
  margin-top: 0%;
  margin: 0%;
}

#lateral-panel-bloc nav ul {
  display: inline-flex;
  flex-direction: column;
  list-style-type: none;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);
  padding: 0px;
  margin: 0%;
  width: 100%;
}

#lateral-panel-bloc nav>ul>li {display: flex; text-align: center; padding: 35.19px;}
#lateral-panel-bloc nav ul li:hover {box-shadow: 2px 2px 5px rgba(0, 0, 0, 0.3);}
#lateral-panel-bloc nav ul a{color: black; text-decoration: none;}

#lateral-panel-input:checked ~ #lateral-panel-label {
  left: 200%;                     /* décalage vers la droite, passe de 100% à 200% */
}

#lateral-panel-input:checked ~ #lateral-panel-bloc {
  transform: translateX(100%);
}

#lateral-panel-label:hover {
background-color: black;
}

#lateral-panel-label, #lateral-panel-bloc {
font-size: inherit;             /* taille font du référent */
background: #FFF;               /* il faut un fond opaque */
box-shadow: 2px 2px 5px rgba(0, 0, 0, 15.3);
transition: all .5s;
}

#lateral-panel-label:before {
  content: "";
  position: absolute;
  top: 50%;
  left: 50%;
  box-sizing: border-box;
  width: 1em;
  height: 1em;
  border: .5em solid currentColor;
  border-width: .5em .5em 0 0;
  color: #888;
  transition: all .5s;
  transform: translate(-50%, -50%) rotate(45deg);
}

#lateral-panel-input:checked ~ #lateral-panel-label:before {
  transform: translate(-50%, -50%) rotate(-135deg);
}

#title {
  position: absolute;
  display: flex;
  justify-content: center;
  top: 15%;
  left: 15%;
  height: 5%;
  width: 70%;
}

#centerblock {
  display: flex;
  position: absolute;
  flex-flow: column ;
  top: 15%;
  left: 15%;
  height: 65%;
  width: 70%;
  overflow: hidden;
}

#connexion, #inscription {
  text-align: center;
  margin:auto;
  box-shadow: 2px 2px 5px rgba(0, 0, 0, 15.3);
  padding: 10px
}

/*footer*/
#bottomblock {
  display: flex;
  justify-content: center;
  position: absolute;
  top: 90%;
  left: 0%;
  width: 100%;
  color: white;
  background-color: black;
}

#social {
  text-align: center;
  width: 100%;
}

#info1 {
  text-align: center;
  width: 100%;
}

#info1 ul {
  list-style-type: none;
}

#info2 {
  text-align: center;
  width: 100%;
}


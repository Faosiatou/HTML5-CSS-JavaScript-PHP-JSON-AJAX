<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/pizza5_css.php">
    <script type="text/javascript" src="js/pizza5_js.php"></script>
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>4 Saisons</u></h2>
    </div>
    <div id="centerblock">
        <div id="blockleft">
            <img src="img/4-saisons.png">
        </div>
        <div id="blockright">
            <div>
            <h3>Ingrédients:</h3>
            <ul>
                <li>Sauce tomate</li>
                <li>Fromage</li>
                <li>Jamon</li>
                <li>Champignons</li>
                <li>Origan</li>
            </ul>
            </div>
            <div id="pstock5">
                <output name="calcul_stock">Stock = 10</output>
            </div>
            <div id="prix">
                Prix: 15,50€
            </div>
            <br>
            <div id="panier">
                <button id="bouton_moins" onclick="moins()">-</button>
                <input type="number" name="quantite" id="quantiteMenu" min="0" max="10" style="width: 2em;">
                <button id="bouton_plus" onclick="plus()">+</button>
                <button id="bouton_Panier">Ajouter au panier</button>
                
            </div>
            <button id="bouton_stock" onclick="afficheStock()">stock</button>
            <div id="description">
                <h3>Description</h4>
                <p></p>
            </div>
        </div>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

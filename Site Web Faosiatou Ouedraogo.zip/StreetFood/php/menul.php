<div id="lateral-panel">
            <input id="lateral-panel-input" type="checkbox">
            <label id="lateral-panel-label" for="lateral-panel-input"></label>
            <div id="lateral-panel-bloc">
                <nav>
                    <ul>
                        <li><a href="index.php">Accueil</a></li>
                        <li><a href="page1.php">Menus</a></li>
                        <li><a href="page2.php">Burgers</a></li>
                        <li><a href="page3.php">Pizzas</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="connexion.php">Connexion</a></li>
                    </ul>
                </nav>
            </div>
        </div>
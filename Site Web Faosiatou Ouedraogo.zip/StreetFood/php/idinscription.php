<!DOCTYPE html>
<html>
<?php 
$username = $_POST['usernames'];
$password = $_POST['passwords'];
$userpass = $username.",".$password;
    if(!empty($username) and !empty($password)) {

        $file = fopen("id.txt", "a+");
        fputs($file, "\n");
        fputs($file, $userpass);
        fclose($file);
        header("Location: ../connexion.php");
    }
    else {
        header("Location: ../inscription.php");
    }
?>
</html>
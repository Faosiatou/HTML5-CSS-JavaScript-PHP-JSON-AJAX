<div id="topblock">
        <a href="index.php"><img class="imagelogo" src="img/street-food-party-logo.png" width="150px"
                height="100px"></a>
        <nav class="menuhead">
            <ul>
                <li><a href="index.php">Accueil</a></li>
                <li><a href="page1.php">Menus</a>
                    <!--<ul>
                        <li><a href="#">page 1</a></li>
                        <li><a href="#">page 2</a></li>
                        <li><a href="#">page 3</a></li>
                        <li><a href="#">page 4</a></li>
                        <li><a href="#">page 5</a></li>
                    </ul>-->
                </li>
                <li><a href="page2.php">Burgers</a>
                    <!--<ul>
                        <li><a href="#">page 1</a></li>
                        <li><a href="#">page 2</a></li>
                        <li><a href="#">page 3</a></li>
                        <li><a href="#">page 4</a></li>
                        <li><a href="#">page 5</a></li>
                    </ul>-->
                </li>
                <li><a href="page3.php">Pizzas</a>
                    <!--<ul>
                        <li><a href="#">page 1</a></li>
                        <li><a href="#">page 2</a></li>
                        <li><a href="#">page 3</a></li>
                        <li><a href="#">page 4</a></li>
                        <li><a href="#">page 5</a></li>
                    </ul>-->
                </li>
                <li><a href="contact.php">Contact</a></li>
                <li><a href="connexion.php">Connexion</a></li>
            </ul>
        </nav>
        <div id="idblock">
            <label>login:<?php if(isset($_SESSION["login"])) {
                echo $_SESSION["login"]; }
                else {
                    echo "none";
                } ?></label>
            <label><a href="panier.php">Mon panier</a></label>
            <form class="deconnexion" method="POST" action="php/deconnexion.php">
                <input type="submit" value="Se déconnecter">
            </form>
        </div>
    </div>
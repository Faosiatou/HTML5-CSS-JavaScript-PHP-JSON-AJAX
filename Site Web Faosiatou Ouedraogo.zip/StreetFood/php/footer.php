<div id="bottomblock">
        <div id="social">
            <h3>Ne manquez rien de notre Actualité !</h3>
            <ul>
                <a href="#"><img src="img/fb.png" width="40px" height="40px"></a>
                <a href="#"><img src="img/twitter.png" width="40px" height="40px" margin-left="10px"
                        margin-right="10px"></a>
                <a href="#"><img src="img/insta.png" width="40px" height="40px"></a>
            </ul>
        </div>
        <div id="info1">
            <h3>Notre restaurant</h3>
            <ul>
                <li>Avenue du Parc, 95000 Cergy</li>
                <li class="lic">Horaires:
                    <ul class="horaires">
                        <li>Du Lundi au Samedi: 11h00-21h00</li>
                        <li>Dimanche: 11h00-14h00</li>
                    </ul>
                </li>
            </ul>
        </div>
        <div id="info2">
            <h3>Copyright © 2021</h3>
            <h5>Développeurs Web : streetfooddevweb@gmail.com</h5>
        </div>
    </div>

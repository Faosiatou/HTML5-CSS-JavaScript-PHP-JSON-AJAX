<?php
 
    session_start();
 
    if (isset($_SESSION["login"])) { 
 
        $_SESSION = array();
        session_destroy();
         
        header("Location: ../index.php?deco=1");
 
    }else{
 
        header("Location: ../index.php?deco=0");
    }
 
         
 
?>
<!DOCTYPE html>
<html>
<?php 
$username = $_POST["usernamef"];
$password = $_POST["passwordf"];
$userpass = $username.",".$password;
echo "$userpass";

$lignefichier = str_replace("\n","",array_unique(file("id.txt")));

for($i = 0; $i < count($lignefichier); $i++) {
    if($userpass == $lignefichier[$i]) {

        session_start();

        $_SESSION["login"] = $username;

        header("Location: ../index.php?id=1");
        exit();
    }
    else {
        header("Location: ../connexion.php?error");
    }
    
}
?>
</html>
<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/connexion_css.php">
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>Connexion</u></h2>
    </div>
    <div id="centerblock">
        <div id="connexion">
        <form  class="formulaireconnexion" method="POST" action="php/connexionver.php">
            <label for="id">Nom Utilisateur:</label>
            <input type="text" name="usernamef" id="usernamef" minlength="2" maxlength="20">
            <br><br>
            <label for="site">mot de passe:</label>
            <input type="password" id="passwordf" name="passwordf" minlength="2" maxlength="30">
            <br><br>
            <input type="submit" value="Se connecter">
        </form>
        <br>
        <label><a href="inscription.php">Vous n'avez pas de compte ?</a></label>
        </div>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

</html>

<?php
include("varSession.inc.php");

try
{
	$bdd = new PDO('mysql:host=localhost;dbname=streetfood;charset=utf8', 'root', 'root');
}
catch(Exception $e)
{
        die('Erreur : '.$e->getMessage());
}



        for($i = 0; $i < 5; $i++) 
        {
            $req = $bdd->prepare('INSERT INTO menus (menu_id, menu_nom, menu_image, menu_ingredients, menu_ingredients2, menu_prix, menu_stock, menu_quantite)
            VALUES(?,?,?,?,?,?,?,?)');


            $req ->execute(array($_SESSION["menuinfo"][$i][0],$_SESSION["menuinfo"][$i][1],$_SESSION["menuinfo"][$i][2],$_SESSION["menuinfo"][$i][3],$_SESSION["menuinfo"][$i][4],$_SESSION["menuinfo"][$i][5],$_SESSION["menuinfo"][$i][6],$_SESSION["menuinfo"][$i][7]));


        }

        for($i = 5; $i < 10; $i++) 
        {
            $req = $bdd->prepare('INSERT INTO burgers (burger_id, burger_nom, burger_image, burger_ingredients, burger_ingredients2, burger_prix, burger_stock, burger_quantite)
            VALUES(?,?,?,?,?,?,?,?)');


            $req ->execute(array($_SESSION["menuinfo"][$i][0],$_SESSION["menuinfo"][$i][1],$_SESSION["menuinfo"][$i][2],$_SESSION["menuinfo"][$i][3],$_SESSION["menuinfo"][$i][4],$_SESSION["menuinfo"][$i][5],$_SESSION["menuinfo"][$i][6],$_SESSION["menuinfo"][$i][7]));


        }

        for($i = 10; $i < 15; $i++) 
        {
            $req = $bdd->prepare('INSERT INTO pizzas (pizza_id, pizza_nom, pizza_image, pizza_ingredients, pizza_ingredients2, pizza_prix, pizza_stock, pizza_quantite)
            VALUES(?,?,?,?,?,?,?,?)');


            $req ->execute(array($_SESSION["menuinfo"][$i][0],$_SESSION["menuinfo"][$i][1],$_SESSION["menuinfo"][$i][2],$_SESSION["menuinfo"][$i][3],$_SESSION["menuinfo"][$i][4],$_SESSION["menuinfo"][$i][5],$_SESSION["menuinfo"][$i][6],$_SESSION["menuinfo"][$i][7]));


        }
?>
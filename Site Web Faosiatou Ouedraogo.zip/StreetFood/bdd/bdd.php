<html>
<head>
<title>menus</title>
</head>
<body>
<table border="1" cellpadding="0" cellspacing="0">
<tr>
<th>menu_id</th>
<th>menu_nom</th>
<th>menu_image</th>
<th>menu_ingredients</th>
<th>menu_ingredients2</th>
<th>menu_prix</th>
<th>menu_stock</th>
<th>menu_quantite</th>
</tr>



<?php
// Récupération des paramètres de connexion
include "bbdData.php";

//$id_connexion = mysqli_connect( [ $host, ] $user, $password [ , $db ] [ , $port ] );


// Connexion à mysql
if ( ! ($id_connexion = mysqli_connect( $host, $user, $password )) ) {
    echo "La connexion n’a pas pu être établie. <br>" ;
    echo "Elle a renvoyé le code erreur " . mysqli_errno( $id_connexion ). "<br>";
    echo "et le message : " . mysqli_error( $id_connexion ) . "<br>";
    }

// Connexion à la base
if ( ! mysqli_select_db( $id_connexion, $db ) ) {
    echo "La connexion à la base a renvoyé une erreur de code " . mysqli_errno( $id_connexion ). " \
    avec le message : " . mysqli_error( $id_connexion ) . "<br>";
    exit;


// Création et envoi de la requête
$query = "SELECT menu_id, menu_nom, menu_image, menu_ingredients, menu_ingredients2, menu_prix, menu_stock, menu_quantite FROM menus ORDER BY menu_nom";
if ( ! ( $result = mysqli_query( $id_connexion, $query ) ) ) {
    echo "Echec de la requête avec le code d’erreur " . mysqli_errno( $id_connexion ). " \
    et le message : " . mysqli_error( $id_connexion ) . "<br>";
    exit;
} else {
    // Récuperation des résultats
    while ( $row = mysqli_fetch_row( $result ) ) {
    $menu_id = $row[0];
    $menu_nom = $row[1];
    $menu_image = $row[2];
    $menu_ingredients = $row[3];
    $menu_ingredients2 = $row[4];
    $menu_prix = $row[5];
    $menu_stock = $row[6];
    $menu_quantite = $row[7];
    echo "<tr>\n<td>$menu_id</td>\n<td>$menu_nom</td>\n<td>$menu_image</td>\n<td>$menu_ingredients</td>\n<td>$menu_ingredients2</td>\n<td>$menu_prix</td>\n<td>$menu_stock</td>\n<td>$menu_quantite</td>\n</tr>\n";
}
}
// Libération de la ressource et déconnexion de la base de données
mysqli_free_result( $result );
mysqli_close( $id_connexion );
?>
</tr> </table> </body> </html>


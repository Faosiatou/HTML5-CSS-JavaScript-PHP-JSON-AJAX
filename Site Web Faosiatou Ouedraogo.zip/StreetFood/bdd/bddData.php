<?php // connexion_data.inc.php
$host="localhost"; // adresse/nom du serveur, localhost par défaut
$port=3306; // port de connexion au serveur
$user="Nom utilisateur"; // login utilisateur
$password="mot de passe"; // mot de passe utilisateur
$db="streetfood"; // base de données à utiliser
?>
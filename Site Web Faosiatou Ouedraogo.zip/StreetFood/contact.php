<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<?php 
if(isset($_POST['mailform']))
{
    if(!empty($_POST['name']) AND !empty($_POST['fname']) AND !empty($_POST['e-mail']) AND !empty($_POST['fonction']) AND !empty($_POST['commande']) AND !empty($_POST['message']))
	{
		$header="MIME-Version: 1.0\r\n";
		$header.='From:"StreetFoodParty.com"<support@StreetFoodParty.com>'."\n";
		$header.='Content-Type:text/html; charset="uft-8"'."\n";
		$header.='Content-Transfer-Encoding: 8bit';

		$message='
		<html>
			<body>
				<div align="center">
					<u>Nom de l\'expéditeur :</u>'.$_POST['name'].'<br />
					<u>Mail de l\'expéditeur :</u>'.$_POST['e-mail'].'<br />
					<br />
					'.nl2br($_POST['message']).'
				</div>
			</body>
		</html>
		';

		mail("streetfoodsite@gmail.com", "CONTACT - StreetFoodParty.com", $message, $header);
		$msg="Votre message a bien été envoyé !";
	}
	else
	{
		$msg="Tous les champs doivent être complétés !";
	}
}
?>

<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/contact_css.php">
    <script type="text/javascript" src="js/contact_js.php"></script>
    <?php include("php/entete.php"); ?>
</head>

<body>
<?php include("php/menul.php"); ?>
<div id="title">
        <h2><u>Contact</u></h2>
    </div>
    <div id="centerblock">
                <form class="formulaire" method="post" onsubmit="return verification()">
                <label for="nom">Nom:</label>
                <input type="text" name="name" id="nom" minlength="2" maxlength="20"><br><br>
                <div id="erreurNom"></div><br>
                <label for="prénom">Prénom:</label>
                <input type="text" name="fname" id="prénom" minlength="2" maxlength="20"><br><br>
                <div id="erreurPrenom"></div><br>
                <label for="e-mail"> E-mail: </label>
                <input type="email" name="e-mail" id="id_e-mail"><br><br>
                <div id="erreurEmail"></div><br>
                <label for="genre">Genre:</label>
                    <input type="radio" id="idman" name="sex" value="man" checked>
                    <label for="man">Homme</label>
                    <input type="radio" id="idwoman" name="sex" value="woman">
                    <label for="woman">Femme</label><br><br>
                <label for="date">Date de naissance:</label>
                <input type="date" id="iddate" name="date"value="2021-01-01" min="1900-01-01" max="2021-12-31"><br><br>
                <div id="erreurDatedenaissance"></div><br>
                <label for="fonction">Fonction:</label>
                    <select id="id_fonc" name="fonction">
                        <option>Choisissez...</option>
                        <option>Agriculteur exploitant</option>
                        <option>Artisan, commerçants et chef d’entreprise</option>
                        <option>Cadre</option>
                        <option>Profession intermédiaire</option>  
                        <option>Employé</option>
                        <option>Ouvrier</option>
                    </select><br><br>
                <div id="erreurFonction"></div><br>
                <label for="MOTIF"> Motif: </label>
                    <select id="id_order" name="commande">
                        <option>Choisissez...</option>
                        <option>Ma commande a été endommagée</option>
                        <option>j'ai reçu une mauvaise commande</option>
                        <option>Demander un remboursement</option>                               
                    </select><br><br>
                <div id="erreurCommande"></div><br>
                <label for="Message">Message:</label>
                <textarea id="id_message" name="message" rows="4" cols="50"></textarea><br><br>
                <div id="erreurMessage"></div><br>
                <input type="submit" value="Envoyer" name="mailform">
                </form>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

</html>

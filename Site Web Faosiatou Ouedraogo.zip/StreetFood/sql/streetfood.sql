DROP DATABASE IF EXISTS streetfood;
CREATE DATABASE streetfood;
USE streetfood;
CREATE TABLE menus (
    menu_id varchar(20) PRIMARY KEY , 
    menu_nom varchar(50), 
    menu_image varchar(50), 
    menu_ingredients varchar(250), 
    menu_ingredients2 varchar(250) ,
    menu_prix varchar(50),
    menu_stock varchar(50), 
    menu_quantite varchar(50)
);

CREATE TABLE burgers (
    burger_id varchar(20) PRIMARY KEY,  
    burger_nom varchar(50),
    burger_image varchar(50),
    burger_ingredients varchar(250),
    burger_ingredients2 varchar(250),
    burger_prix varchar(50),
	burger_stock varchar(50), 
    burger_quantite varchar(50)
);

CREATE TABLE pizzas (
    pizza_id varchar(20) PRIMARY KEY,  
    pizza_nom varchar(50),
    pizza_image varchar(50),
    pizza_ingredients varchar(250),
    pizza_ingredients2 varchar(250),
    pizza_prix varchar(50),
	pizza_stock varchar(50), 
    pizza_quantite varchar(50)
);
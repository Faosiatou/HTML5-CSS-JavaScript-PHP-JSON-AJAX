<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/menu3_css.php">
    <script type="text/javascript" src="js/menu3_js.php"></script>
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>Menu Double Cheese Bacon</u></h2>
    </div>
    <div id="centerblock">
        <div id="blockleft">
            <img src="img/menu_double_cheese_bacon.jpeg">
        </div>
        <div id="blockright">
            <div>
            <h3>Menu</h3>
            <ul>
                <li>Burger Double Cheese Bacon
                    <ul>
                        <li for="ingrédient">Bacon</li>
                        <li for="ingrédient">Sauce barbecue</li>
                        <li for="ingrédient">2 Viande de bœuf grillée</li>
                        <li for="ingrédient">Fromage fondu</li>
                    </ul>
                </li>
                <li>Dessert</li>
                <li>Boisson</li>
            </ul>
            </div>
            <div id="mstock3">
                <output name="calcul_stock">Stock = 10</output>
            </div>
            <div id="prix3">
                Prix: 11,50€
            </div>
            <br>
            <div id="panier">
                <button id="bouton_moins" onclick="moins()">-</button>
                <input type="number" name="quantite" id="quantiteMenu" min="0" max="10" style="width: 2em;">
                <button id="bouton_plus" onclick="plus()">+</button>
                <button id="bouton_Panier">Ajouter au panier</button>
                
            </div>
            <button id="bouton_stock" onclick="afficheStock()">stock</button>
            <div id="description">
                <h3>Description</h4>
                <p></p>
            </div>
        </div>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

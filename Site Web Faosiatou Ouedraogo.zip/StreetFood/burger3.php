<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/burger3_css.php">
    <script type="text/javascript" src="js/burger3_js.php"></script>
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>Triple Cheese</u></h2>
    </div>
    <div id="centerblock">
        <div id="blockleft">
            <img src="img/triple_cheese.jpeg">
        </div>
        <div id="blockright">
            <div>
            <h3>Ingrédients:</h3>
            <ul>
                <li>2 rondelles de cornichons</li>
                <li>Bacon</li>
                <li>Ketchup & Moutarde</li>
                <li>3 Viande de bœuf grillée</li>
                <li>3 Tranches de fromage fondu</li>
            </ul>
            </div>
            <div id="bstock3">
                <output name="calcul_stock">Stock = 10</output>
            </div>
            <div id="prix">
                Prix: 5,30€
            </div>
            <br>
            <div id="panier">
                <button id="bouton_moins" onclick="moins()">-</button>
                <input type="number" name="quantite" id="quantiteMenu" min="0" max="10" style="width: 2em;">
                <button id="bouton_plus" onclick="plus()">+</button>
                <button id="bouton_Panier">Ajouter au panier</button>
                
            </div>
            <button id="bouton_stock" onclick="afficheStock()">stock</button>
            <div id="description">
                <h3>Description</h4>
                <p></p>
            </div>
        </div>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

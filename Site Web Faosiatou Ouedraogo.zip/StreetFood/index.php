<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
echo $_SESSION["login"];
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/index_css.php">
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>Bienvenue</u></h2>
    </div>
    <div id="centerblock">
        <a href="menu3.php"><img id="promo" src="img/menu_double_steakhouse.jpeg"></a>
        <h3>Découvrez notre nouveau menu</h3>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

</html>
<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/menu5_css.php">
    <script type="text/javascript" src="js/menu5_js.php"></script>
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>Menu 2 Personnes</u></h2>
    </div>
    <div id="centerblock">
        <div id="blockleft">
            <img src="img/menu_2_personnes.png">
        </div>
        <div id="blockright">
            <div>
            <h3>Menu</h3>
            <ul>
                <li for="ingrédient">2 pizzas au choix</li>
                <li for="ingrédient">Dessert au choix</li>
                <li for="ingrédient">Boisson au choix</li>
            </ul>
            </div>
            <div id="mstock5">
                <output name="calcul_stock">Stock = 10</output>
            </div>
            <div id="prix5">
                Prix: 32,50€
            </div>
            <br>
            <div id="panier">
                <button id="bouton_moins" onclick="moins()">-</button>
                <input type="number" name="quantite" id="quantiteMenu" min="0" max="10" style="width: 2em;">
                <button id="bouton_plus" onclick="plus()">+</button>
                <button id="bouton_Panier">Ajouter au panier</button>
                
            </div>
            <button id="bouton_stock" onclick="afficheStock()">stock</button>
            <div id="description">
                <h3>Description</h4>
                <p></p>
            </div>
        </div>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

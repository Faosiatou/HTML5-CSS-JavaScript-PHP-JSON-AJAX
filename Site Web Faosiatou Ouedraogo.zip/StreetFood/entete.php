<div id="tb">
        <div id="logo">
            <a href="index.php"><img class="logo" src="img/street-food-party-logo.png" width="200px" height="100px"></a>
        </div>
        <div id="utb" class="utb">
            <nav class="menuh">
                <ul>
                    <li><a href="page1.php">Menus</a>
                        <!--<ul><li><a href="page1.php"><img class="logo" src="" width="10px" height="10px">Menus 1</a></li>
                        <li><a href="page1.php"><img class="logo" src="" width="10px" height="10px">Menus 2</a></li>
                        <li><a href="page1.php"><img class="logo" src="" width="10px" height="10px">Menus 3</a></li>
                    </ul>-->
                    </li>
                    <li><a href="page2.php">Burgers</a>
                        <!--<ul><li><a href="page2.php"><img class="logo" src="" width="10px" height="10px">Burger 1</a></li>
                        <li><a href="page2.php"><img class="logo" src="" width="10px" height="10px">Burger 2</a></li>
                        <li><a href="page2.php"><img class="logo" src="" width="10px" height="10px">Burger 3</a></li>
                    </ul>-->
                    </li>
                    <li><a href="page3.php">Pizzas</a>
                        <!--<ul><li><a href="page3.php"><img class="logo" src="" width="10px" height="10px">Pizza 1</a></li>
                        <li><a href="page3.php"><img class="logo" src="" width="10px" height="10px">Pizza 2</a></li>
                        <li><a href="page3.php"><img class="logo" src="" width="10px" height="10px">Pizza 3</a></li>
                    </ul>-->
                    </li>
                    <li><a href="contact.php">Contact</a></li>
                    <li class="recherche"><input type="search" id="site-search" name="q"
                            aria-label="Search through site content" width="100px" height="20px"></li>
                    <li class="logor"><button><img src="img/loupe.png" width="20px" height="20px"></button></li>
                    <li class="id"><a href="connexion.php">S'identifier</a>
                        <ul>
                            <form method="post" action="php/traitement.php">
                                <label for="site">e-mail:</label>
                                <input type="email" id="site" name="q">
                                <label for="site">mot de passe:</label>
                                <input type="password" id="site" name="q">
                                <input type="submit" value="Se connecter">
                                <a href="#">Nouveau client ?</a>
                            </form>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
        <div id="panier">
            <nav class="panier">
                <ul>
                    <li><a href="panier.php">Panier</a></li>
                </ul>
            </nav>
        </div>
    </div>

<!DOCTYPE html>
<?php
    session_start();
    include("varSession.inc.php");
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/page1_css.php">
    <script type="text/javascript" src="js/page1_js.php"></script>
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>Nos Menus</u></h2>
    </div>
    <div id="centerblock">
        <?php
            for($i = 0; $i < 5; $i++) {
        ?>
                <div id=<?php echo $_SESSION["menuinfo"][$i][0]; ?>>
                    <legend class="nom_produit" name="nom_produit"><?php echo $_SESSION["menuinfo"][$i][1]; ?></legend>
                    <a href="menu1.php"><img class="img" name="img" src=<?php echo $_SESSION["menuinfo"][$i][2] ; ?> onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
                    <label for=ingredient><?php echo $_SESSION["menuinfo"][$i][3]; ?> </label>
                    <label for=ingredient><?php echo $_SESSION["menuinfo"][$i][4]; ?></label><br>
                    <label class="prix"><?php echo $_SESSION["menuinfo"][$i][5]; ?></label>
                    <div id =<?php echo $_SESSION["menuinfo"][$i][6]; ?>>
                        <output name="calcul_stock">Stock = 10</output>
                    </div>
                    <div id = "panier">
                        <button id = "bouton_moins" onclick="moins(<?php echo $i+1 ; ?>)">-</button>
                        <input class="quantity" type="number" name="quantity" id=<?php echo $_SESSION["menuinfo"][$i][7]; ?> min="0" max="10" style="width: 2em;" >
                        <button id = "bouton_plus" onclick="plus(<?php echo $i+1 ; ?>)">+</button>
                        <input type="submit" value="Ajouter au panier">
                    </div>  
                </div>
        <?php
            }
        ?>
        <button id = "bouton_stock" onclick="afficheStock()">stock</button>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

</html>

<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
/*
$produit = $_POST["nom_produit"];
$_prix = $_POST["prix"];
$_img = $_POST["img"];
$_quantity = $_POST["quantity"]
*/
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/panier_css.php">
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>Panier</u></h2>
    </div>
    <div id="centerblock">
    <div id="b1">>
                    <legend><?php echo $_produit; ?></legend>
                    <img src=<?php echo $_img; ?> onmouseover="zoom(this)" onmouseout="normal_img(this)">
                    <label><?php echo $_prix; ?></label>
                    <div id = "panier">
                        <input type="number" min="0" max="10" style="width: 2em;" >
                    </div> 
                </div>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

</html>

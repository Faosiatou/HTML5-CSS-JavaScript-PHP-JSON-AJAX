<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/page2_css.php">
    <script type="text/javascript" src="js/page2_js.php"></script>
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>Nos Burgers</u></h2>
    </div>
    <div id="centerblock">
    <?php
            for($i = 5; $i < 10; $i++) {
        ?>
                <div id=<?php echo $_SESSION["menuinfo"][$i][0]; ?>>
                    <legend><?php echo $_SESSION["menuinfo"][$i][1]; ?></legend>
                    <a href="burger1.php"><img src=<?php echo $_SESSION["menuinfo"][$i][2] ; ?> onmouseover="zoom(this)" onmouseout="normal_img(this)"></a>
                    <label for=ingredient><?php echo $_SESSION["menuinfo"][$i][3]; ?> </label>
                    <label for=ingredient><?php echo $_SESSION["menuinfo"][$i][4]; ?></label><br>
                    <label><?php echo $_SESSION["menuinfo"][$i][5]; ?></label>
                    <div id =<?php echo $_SESSION["menuinfo"][$i][6]; ?>>
                        <output name="calcul_stock">Stock = 10</output>
                    </div>
                    <div id = "panier">
                        <button id="bouton_moins" onclick="moins(<?php echo $i+1 ; ?>)">-</button>
                        <input type="number" name="quantite" id=<?php echo $_SESSION["menuinfo"][$i][7]; ?> min="0" max="10" style="width: 2em;" >
                        <button id="bouton_plus" onclick="plus(<?php echo $i+1 ; ?>)">+</button>
                        <button id="bouton_Panier">Ajouter au panier</button>
                    </div>
                        
                </div>
        <?php
            }
        ?>
        <button id = "bouton_stock" onclick="afficheStock()">stock</button>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

</html>

<?php
$Session_ID = session_id();



$_SESSION["menuinfo"] = array(

    array("b1", "MENU STEAKHOUSE", "img/menu_steakhouse.jpeg", "1 burger steakhouse", "+ frittes + 1 boisson", "9,95€", "stock1", "quantiteMenu1"),
    array("b2", "MENU DOUBLE CHEESE BACON", "img/menu_double_cheese_bacon.jpeg", "1 burger double cheese bacon", "+ frittes + 1 boisson", "10,95€", "stock2", "quantiteMenu2"),
    array("b3", "MENU DOUBLE STEAKHOUSE", "img/menu_double_steakhouse.jpeg", "1 burger double steakhouse", "+ frittes + 1 boisson", "11,50€", "stock3", "quantiteMenu3"),
    array("b4", "MENU SOLO", "img/menu_solo.png", "1 pizza au choix", "+ 1 dessert +1 boisson", "20,90€", "stock4", "quantiteMenu4"),
    array("b5", "MENU 2 PERSONNES", "img/menu_2_personnes.png", "2 pizzas au choix", "+ 2 boissons + 2 desserts", "32,50€", "stock5", "quantiteMenu5"),
    
    array("b1", "STEAKHOUSE", "img/steakhouse.jpeg", "Oignons croustillants, Fromage fondu", "Sauce barbecue, Viande de bœuf, Bacon", "6,50€", "stock1", "quantiteMenu"),
    array("b2","DOUBLE STEAKHOUSE", "img/double_steakhouse.jpeg", "2 viandes de bœuf, Oignons croustillants", "Bacon, Sauce Barbecue, Fromage fondu ", "8,50€", "stock2", "quantiteMenu2"),
    array("b3", "TRIPLE CHEESE", "img/triple_cheese.jpeg", "Ketchup & Moutarde", "3 Viande de bœuf grillée, 3 Tranches de fromage fondu", "5,30€", "stock3", "quantiteMenu3"),
    array("b4", "DOUBLE CHEESE BACON", "img/double_cheese_Bacon.jpeg", "Bacon, 2 Viande de bœuf grillée", "Sauce barbecue, Fromage fondu ", "7,50€", "stock4", "quantiteMenu4"),
    array("b5", "CRISPY CHICKEN", "img/crispy_chicken.jpeg", "Poulet croustillant, Salade ", "Tomates, Mayonnaise", "4,50€", "stock5", "quantiteMenu5"),

    array("b1", "REINE", "img/reine.png", "Sauce tomate, Fromage", "Jambon, Champignons, Origan", "15,50€", "stock1", "quantiteMenu"),
    array("b2","VEGETARIENNE", "img/vegetarienne.png", "Tomate, Fromage, Poivrons", "Champignons, Olives, Origan ", "15,50€", "stock2", "quantiteMenu2"),
    array("b3", "MEXICAINE", "img/mexicaine.png", "Tomate, Merguez, Pepperoni", "poivrons, olives, fromage, Origan", "16€", "stock3", "quantiteMenu3"),
    array("b4", "4 FROMAGES", "img/4fromages.png", "Tomate, Mozzarella, gorgonzola, chèvre", "Parmesan, Provolone, Fromage à raclette ", "16,50€", "stock4", "quantiteMenu4"),
    array("b5", "4 SAISONS", "img/4-saisons.png", "Tomate, Fromage, Jambon ", "Champignons, Origan", "15,50€", "stock5", "quantiteMenu5")

);


?>
<!DOCTYPE html>
<?php
session_start();
$Session_ID = session_id();
?>
<html>

<head>
    <meta charset="utf-8">
    <meta author="FaosiatouOUEDRAOGO-Teggar Farès">
    <link rel="stylesheet" type="text/css" href="css/pizza4_css.php">
    <script type="text/javascript" src="js/pizza4_js.php"></script>
    <?php include("php/entete.php"); ?>
</head>

<body>
    <?php include("php/menul.php"); ?>
    <div id="title">
        <h2><u>4 Fromages</u></h2>
    </div>
    <div id="centerblock">
        <div id="blockleft">
            <img src="img/4fromages.png">
        </div>
        <div id="blockright">
            <div>
            <h3>Ingrédients:</h3>
            <ul>
                <li>Sauce tomate</li>
                <li>Mozzarella</li>
                <li>Provolone</li>
                <li>gorgonzola</li>
                <li>Chèvre</li>
                <li>Parmesan</li>
                <li>Fromage à raclette</li>
            </ul>
            </div>
            <div id="pstock4">
                <output name="calcul_stock">Stock = 10</output>
            </div>
            <div id="prix">
                Prix: 16,50€
            </div>
            <br>
            <div id="panier">
                <button id="bouton_moins" onclick="moins()">-</button>
                <input type="number" name="quantite" id="quantiteMenu" min="0" max="10" style="width: 2em;">
                <button id="bouton_plus" onclick="plus()">+</button>
                <button id="bouton_Panier">Ajouter au panier</button>
                
            </div>
            <button id="bouton_stock" onclick="afficheStock()">stock</button>
            <div id="description">
                <h3>Description</h4>
                <p></p>
            </div>
        </div>
    </div>
</body>
<footer>
    <?php include("php/footer.php"); ?>
</footer>

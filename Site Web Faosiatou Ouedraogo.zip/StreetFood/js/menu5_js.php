var etatBoutonStock = 0;
function afficheStock()
{
    div_stock1 = document.getElementById("mstock5").style;
    var etatBoutonstock = 0;

    if(etatBoutonStock == 0)
    {
        div_stock1.visibility = "hidden";
        etatBoutonStock = 1;
    }
    else{
        div_stock1.visibility = "visible";
        etatBoutonStock = 0;
    }
}


function moins()
{
    if(document.getElementById("quantiteMenu").value > 0)
    {
         document.getElementById("quantiteMenu").value --;
    }
}

function plus()
{
    if(document.getElementById("quantiteMenu").value < 10)
    {
   
        document.getElementById("quantiteMenu").value ++;
    }
    
}
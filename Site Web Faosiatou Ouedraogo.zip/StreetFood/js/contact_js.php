//Fonction zoom//
function zoom(image)
{
    image.style.width = "200px";
}

function normal_img(image)
{
    image.style.width = "160px" ;
}

/////////////////////////////////
//Fonction Vérification Formulaire//
function verification() {
    var erreur=false;
    var nom=document.getElementById("nom");
    var prenom=document.getElementById("prénom");
    var email=document.getElementById("id_e-mail");
    var fonc=document.getElementById("id_fonc");
    var order=document.getElementById("id_order");
    var message=document.getElementById("id_message");
    if(nom.value=="") {
       
        nom.style.border="1px solid red";
        document.getElementById("erreurNom").innerHTML="Nom invalide ou vide";
        erreur=true;
    }
    else {
        nom.style.border="1px solid gray";
        document.getElementById("erreurNom").innerHTML="";
    } 
    if(prenom.value=="") {
        prenom.style.border="1px solid red";
        document.getElementById("erreurPrenom").innerHTML="Prénom invalide ou vide";
        erreur=true;
    }
    else {
        prenom.style.border="1px solid gray";
        document.getElementById("erreurPrenom").innerHTML="";
    }
    if(email.value=="") {
        email.style.border="1px solid red";
        document.getElementById("erreurEmail").innerHTML="E-mail invalide ou vide";
        erreur=true;
    }
    else {
        email.style.border="1px solid gray";
        document.getElementById("erreurEmail").innerHTML="";
    }
    if(fonc.value=="Choisissez...") {
        fonc.style.border="1px solid red";
        document.getElementById("erreurFonction").innerHTML="Fonction invalide";
        erreur=true;
    }
    else {
        fonc.style.border="1px solid gray";
        document.getElementById("erreurFonction").innerHTML="";
    }
    if(order.value=="Choisissez...") {
        order.style.border="1px solid red";
        document.getElementById("erreurCommande").innerHTML="Veuillez entrer une option";
        erreur=true;
    }
    else {
        order.style.border="1px solid gray";
        document.getElementById("erreurCommande").innerHTML="";
    }
    if(message.value=="") {
        message.style.border="1px solid red";
        document.getElementById("erreurMessage").innerHTML="Veuillez entrer un message";
        erreur=true;
    }
    else {
        message.style.border="1px solid gray";
        document.getElementById("erreurMessage").innerHTML="";
    }
    return !erreur;
}

function valuebirthday() {
    var value= new Date;
    return document.write(value.getDate+"/"+value.getMonth+"/"+value.getFullYear);
}
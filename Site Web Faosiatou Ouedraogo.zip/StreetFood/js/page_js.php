var  etatBoutonStock = 0;

function zoom(image)
{
    image.style.width = "100%";
}

function normal_img(image)
{
    image.style.width = "80%" ;
}

function afficheStock()
{
    div_stock1 = document.getElementById("stock1").style;
    div_stock2 = document.getElementById("stock2").style;
    div_stock3 = document.getElementById("stock3").style;
    div_stock4 = document.getElementById("stock4").style;
    div_stock5 = document.getElementById("stock5").style;
    
    if(etatBoutonStock == 0)
    {
        div_stock1.visibility = "hidden";
        div_stock2.visibility = "hidden";
        div_stock3.visibility = "hidden";
        div_stock4.visibility = "hidden";
        div_stock5.visibility = "hidden";
        etatBoutonStock = 1;
    }
    else{
        div_stock1.visibility = "visible";
        div_stock2.visibility = "visible";
        div_stock3.visibility = "visible";
        div_stock4.visibility = "visible";
        div_stock5.visibility = "visible";
        etatBoutonStock = 0;
    }
}


function moins1()
{
    if(document.getElementById("quantiteMenu1").value > 0)
    {
         document.getElementById("quantiteMenu1").value --;
    }
}

function plus1()
{
    if(document.getElementById("quantiteMenu1").value < 10)
    {
   
        document.getElementById("quantiteMenu1").value ++;
    }
    
}


function moins2()
{
    if(document.getElementById("quantiteMenu2").value > 0)
    {
         document.getElementById("quantiteMenu2").value --;
    }
}

function plus2()
{
   
    if(document.getElementById("quantiteMenu2").value < 10)
    {
   
        document.getElementById("quantiteMenu2").value ++;
    }
    
}

function moins3()
{
    if(document.getElementById("quantiteMenu3").value > 0)
    {
         document.getElementById("quantiteMenu3").value --;
    }
}

function plus3()
{
   
    if(document.getElementById("quantiteMenu3").value < 10)
    {
   
        document.getElementById("quantiteMenu3").value ++;
    }
    
}

function moins4()
{
    if(document.getElementById("quantiteMenu4").value > 0)
    {
         document.getElementById("quantiteMenu4").value --;
    }
}

function plus4()
{
   
    if(document.getElementById("quantiteMenu4").value < 10)
    {
   
        document.getElementById("quantiteMenu4").value ++;
    }
    
}

function moins5()
{
    if(document.getElementById("quantiteMenu5").value > 0)
    {
         document.getElementById("quantiteMenu5").value --;
    }
}

function plus5()
{
   
    if(document.getElementById("quantiteMenu5").value < 10)
    {
   
        document.getElementById("quantiteMenu5").value ++;
    }
    
}
